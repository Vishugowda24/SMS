module.exports = {
    packages: {
      'angular2-text-mask': {
        ignorableDeepImportMatchers: [/ol\//]

        // ignorableDeepImportMatchers: [
        //   /text-mask-core\//,
          
        // ]
      },
    },
  };