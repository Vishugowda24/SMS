import { Injectable } from '@angular/core';
import { UserContext } from '../models/user-context'
import { BehaviorSubject, Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
public currentUserSubject : BehaviorSubject<UserContext>;
public currentUertContext : Observable<UserContext>;
private decodedToken :String;

  constructor() { }

  public login()
  {
    this.currentUserSubject.next(null);
    this.currentUserSubject.next(this.getCurrentUserContextFromToken())
  }

  public getCurrentUserContextFromToken() : any
  {
    return new UserContext('Vishwanatha Gowda','Vishwanatha','Gowda','vishugowda.24@gmail.com');
    
  }

  public getCurrentUser()
  {
    return this.currentUserSubject.value;
  }
}
