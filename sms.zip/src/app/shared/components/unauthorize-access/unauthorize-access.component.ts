import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unauthorize-access',
  templateUrl: './unauthorize-access.component.html',
  styleUrls: ['./unauthorize-access.component.css']
})
export class UnauthorizeAccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
