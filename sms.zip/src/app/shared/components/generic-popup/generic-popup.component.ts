import { Component, OnInit ,Input,Output} from '@angular/core';
import { EventEmitter } from 'events';
import { using } from 'rxjs';
import { PopupType} from '../../models/constants'
@Component({
  selector: 'app-generic-popup',
  templateUrl: './generic-popup.component.html',
  styleUrls: ['./generic-popup.component.css']
})
export class GenericPopupComponent implements OnInit {

  constructor() { }
  @Input() headerText: string;
  @Input() bodyText: string;
  @Input() okText: string;
  @Input() popupType: number;
  @Input() hieCancel: boolean;
  public PopupCss : string;
  @Output() onclose = new EventEmitter();
  ngOnInit() {
    if (this.popupType == PopupType.Error)
    {
      this.PopupCss = "cssError";
    }
    else
    {
      this.PopupCss = "cssWarning";
      
    }
  }

  onCancelClick()
  {
    this.onclose.emit("false");
  };

  onOkClick()
  {
    this.onclose.emit("true");
  }

}
