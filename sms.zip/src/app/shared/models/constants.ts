export enum PopupType {
Error =1 ,
Warning = 2
}
