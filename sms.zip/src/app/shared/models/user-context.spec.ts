import { UserContext } from './user-context';

describe('UserContext', () => {
  it('should create an instance', () => {
    expect(new UserContext()).toBeTruthy();
  });
});
