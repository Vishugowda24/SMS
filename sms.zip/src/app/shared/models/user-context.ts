export class UserContext {
    public UserName :string;
    public FirstName:string;
    public LastName:string;
    public Email:string;

    constructor(userName:string,firstName:string,
        lastName:string,
        email:string)
        {
            this.UserName = userName;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Email = email;
        }
}
