import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {  LoginComponent} from './components/login/login.component'
import {  UnauthorizeAccessComponent} from './components/unauthorize-access/unauthorize-access.component'

const routes: Routes = [
  {
    path:'login',component:LoginComponent},
   { path : 'unauthorize' ,component : UnauthorizeAccessComponent}
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SharedRoutingModule { }
