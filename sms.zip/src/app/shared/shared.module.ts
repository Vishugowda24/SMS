import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router'
import { NavBarComponent } from './components/nav-bar/nav-bar.component'
import {  LoginComponent} from './components/login/login.component'
import {  UnauthorizeAccessComponent} from './components/unauthorize-access/unauthorize-access.component'
import { AuthenticationService  } from './services/authentication.service'
import {AuthguardGuard} from './helpers/authguard.guard'
import { HttpClientModule} from '@angular/common/http'
import { CookieService} from 'ngx-cookie-service'
import {  SharedRoutingModule} from './shared-routing.module'
import { ModalModule } from 'ngx-bootstrap/modal';
import { GenericPopupComponent } from './components/generic-popup/generic-popup.component';

//import {  } from 'ngx-bootstrap'
@NgModule({
  declarations: [NavBarComponent,LoginComponent,UnauthorizeAccessComponent, GenericPopupComponent],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    RouterModule,
    SharedRoutingModule
    ,
    ModalModule.forRoot()
  ],
  providers : [AuthenticationService,CookieService,AuthguardGuard],
  exports :[NavBarComponent,UnauthorizeAccessComponent,LoginComponent,GenericPopupComponent],
})
export class SharedModule { }
