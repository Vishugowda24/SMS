import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AitsearchComponent } from './components/aitsearch.component';
import {AdminRoutingModule } from './admin-routing.module';
import { AitComponent } from './components/ait/ait.component'
import { AgGridModule } from 'ag-grid-angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSliderModule } from '@angular/material/slider';
import { DatapullComponent } from './components/datapull/datapull.component';
import {MatTableModule} from '@angular/material/table';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTooltip } from '@angular/material/tooltip';
import {MatIconModule} from '@angular/material/icon';
 import {MatDialogModule} from '@angular/material/dialog';
import { DatapullviewComponent } from './components/datapullview/datapullview.component';



@NgModule({
  declarations: [AitsearchComponent, AitComponent, DatapullComponent, DatapullviewComponent],
  imports: [
    CommonModule,
    AdminRoutingModule,
    ReactiveFormsModule,
    MatSliderModule,
    MatTableModule,
     MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
     MatDialogModule,
    AgGridModule.withComponents([])
  ],
})
export class AdminModule { }
