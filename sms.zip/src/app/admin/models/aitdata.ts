export class AitData {
    public mode : string;
    public id : number;
    public aitNumber:string;
    public aitDescription : string;
    public  aitContactName : string;
    public aitEmail : string;

    constructor(_mode :string='A',_id : number=0,
        _aitNumber:string='',
        _aitDescription : string='',
        _aitContactName : string='',
        _aitEmail : string='')
        {
            this.mode = _mode;
            this.id = _id;
            this.aitNumber = _aitNumber;
            this.aitDescription = _aitDescription;
            this.aitContactName = _aitContactName;
            this.aitEmail = _aitEmail;
        }

}
