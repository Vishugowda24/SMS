import { Aitdata } from './aitdata';

describe('Aitdata', () => {
  it('should create an instance', () => {
    expect(new Aitdata()).toBeTruthy();
  });
});
