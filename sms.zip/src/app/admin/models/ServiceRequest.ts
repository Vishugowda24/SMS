export class ServiceRequest {
    public Url : string;
   
    constructor(_Url :string='A')
        {
            this.Url = _Url;
           
        }

}
