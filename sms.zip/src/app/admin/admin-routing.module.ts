import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {  AitsearchComponent} from './components/aitsearch.component'
import { AitComponent } from './components/ait/ait.component'
import { DatapullComponent } from './components/datapull/datapull.component';

const adminRoutes: Routes = [
  {path:'',component : AitsearchComponent},
  {
    path:'AitSearch',component:AitsearchComponent},
    {path:'Ait', component:AitComponent},
    {path:'DataPull', component:DatapullComponent},

    
    
    {path:'*',component:AitsearchComponent}
   
  
];

@NgModule({
  imports: [RouterModule.forChild(adminRoutes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }

//d
