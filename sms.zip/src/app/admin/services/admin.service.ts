import { Injectable } from '@angular/core';


import { HttpClient,HttpHeaders } from '@angular/common/http'
import { Observable,BehaviorSubject,throwError } from 'rxjs'
import { environment} from '../../../environments/environment'

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  public baseUrl : string;
  constructor(private http: HttpClient) {
    this.baseUrl = environment.baseUrl;
   }

  getAllUser(): Observable<any> {
    return this.http.get<any>('http://localhost:3000/users')
  }

  submitAit(obj:any) : Observable<any>{
    const reqUrl =this.baseUrl + "/api/SMSAdmin/SaveAIT"
    return this.http.post<any>(reqUrl,obj).pipe(

    )
  }

  getServices(): Observable<any> {
    const reqUrl =this.baseUrl + "api/SMSAdmin/Services"
    return this.http.get(reqUrl);
  }

  getServiceData(request:any): Observable<any> {
    const reqUrl =this.baseUrl + "api/SMSAdmin/ServiceData"
    let headers = new HttpHeaders({
      'Content-Type': 'application/json; charset=utf-8',
      
  });
 // let options = new RequestOptions({ headers: headers })

//  const header = new HttpHeaders();
//  const pass = 'Basic ' + btoa(cuid + ': ');
//  header.set('Authorization', pass);
 const options =  ({
   headers: headers
 });
    return this.http.post(reqUrl,request, options);
  }

} 
