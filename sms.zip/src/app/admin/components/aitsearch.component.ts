import { Component, OnInit ,TemplateRef,Input,Output,ElementRef,ViewChild} from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { AdminService } from '../services/admin.service'
import { GenericPopupComponent } from '../../shared/components/generic-popup/generic-popup.component';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { of ,pipe} from 'rxjs';
import { map,filter } from 'rxjs/operators';

@Component({
  selector: 'app-aitsearch',
  templateUrl: './aitsearch.component.html',
  styleUrls: ['./aitsearch.component.css']
})
export class AitsearchComponent implements OnInit {
  
  modalRef: BsModalRef;
  constructor(private modalService: BsModalService, private  adminService:AdminService) {
//   const nums= of(1,2,3,4,5);
//   const nums1= of(1,2,3,4,5);



//   const squareOddVals = pipe(
//     filter((n: number) => n % 2 == 0),
//     map(n => n * n)
//   );

//   const squareOdd = squareOddVals(nums);

// // Subscribe to run the combined functions
// squareOdd.subscribe(x => console.log(x));


const squareOdd = of(1, 2, 3, 4, 5)
  .pipe(
    filter(n => n % 2 !== 0),
    map(n => n * n)
  );

// Subscribe to get values
squareOdd.subscribe(x => console.log(x));
   
  }

  
  ngOnChanges(changes: any) {
    console.log("ngOnChanges - data is");
    for (let key in changes) {
     
   console.log(changes[key].currentValue);
   console.log(changes[key].previousValue );

 // Previous: ${changes[key].previousValue}`);
    }
  } 

  

  ngDoCheck() {
    console.log("ngDoCheck")
  }

  ngAfterContentInit() {
    console.log("ngAfterContentInit");
  }

  ngAfterContentChecked() {
    console.log("ngAfterContentChecked");
  }

  ngAfterViewInit() {
    console.log("ngAfterViewInit");
  }

  ngAfterViewChecked() {
    console.log("ngAfterViewChecked");
  }

  ngOnDestroy() {
    console.log("ngOnDestroy");
  }
  public headerText: string;
  public bodyText: string;
  public okText: string;
  public hideCancel:boolean;
  public AitSearchForm : FormGroup;

columnDefs = [
  {headerName: 'Make', field: 'make' },
  {headerName: 'Model', field: 'model' },
  {headerName: 'Price', field: 'price'}
];

rowData = [
  { make: 'Toyota', model: 'Celica', price: 35000 },
  { make: 'Ford', model: 'Mondeo', price: 32000 },
  { make: 'Porsche', model: 'Boxter', price: 72000 }
];
  @ViewChild("aitSearchPopup") popuRef = ElementRef;

  openModal() {
    this.modalRef = this.modalService.show(this.popuRef, {class:"modal-lg"});
  }


  createAitSearchForm()
  {
    this.AitSearchForm = 
    new FormGroup({
        aitNumber: new FormControl("",{
          validators : [Validators.required,
            Validators.min(1),
          Validators.maxLength(10000)
         ]
        })});
  }

  NodeCall()
  {
    this.adminService.getAllUser().subscribe(i => console.log(i));
    return false;
  }
  ngOnInit() {
    this.headerText = "Test";
    this.bodyText = "body";
    this.okText = "Ok";
    this.hideCancel = false;

    this.createAitSearchForm();
    console.log("ngOnInit  - data is" );
  }

  onClose(data:any)
  {
    this.modalRef.hide();
  }
}
