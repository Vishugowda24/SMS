import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatapullviewComponent } from './datapullview.component';

describe('DatapullviewComponent', () => {
  let component: DatapullviewComponent;
  let fixture: ComponentFixture<DatapullviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatapullviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatapullviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
