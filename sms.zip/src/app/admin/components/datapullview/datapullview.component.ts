import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-datapullview',
  templateUrl: './datapullview.component.html',
  styleUrls: ['./datapullview.component.css']
})
export class DatapullviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
