import { Component, OnInit ,Input,Output,EventEmitter} from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { using } from 'rxjs';
import { AitData} from '../../models/aitdata'

@Component({
  selector: 'app-ait',
  templateUrl: './ait.component.html',
  styleUrls: ['./ait.component.css']
})
export class AitComponent implements OnInit {

  public aitForm : FormGroup;
  public aitData : AitData;
  @Output() onclose = new EventEmitter();
  constructor() { }

  // aitForm = new FormGroup({
  //   AitNumber: new FormControl(''),
  //   AitDescription: new FormControl(''),
  //   AitContactName: new FormControl(''),
  //   AitEmail: new FormControl('')
  // });

  createAitForm()
  {
    this.aitForm = 
    new FormGroup({
        aitNumber: new FormControl("",{
          validators : [Validators.required,
            Validators.min(1),
          Validators.maxLength(10000),
          Validators.pattern(/^-?(0|[1-9]\d*)?$/)]
        }),
        aitDescription: new FormControl("",{
          validators : [Validators.required,
          Validators.maxLength(100)]
        }),
        aitContactName: new FormControl("",{
          validators : [Validators.required,
          Validators.maxLength(100)]
        }),
        aitEmail: new FormControl("",{
          validators : [Validators.required,
          Validators.maxLength(100),
          Validators.email
        ]
        }),
      });
  }
  get f()
  {
    return this.aitForm.controls;
  }
  ngOnInit() {
    this.createAitForm();
  }

  onSubmit()
  {
    
    this.aitData = new AitData('A',0,this.aitForm.controls["aitNumber"].value,
    this.aitForm.controls["aitDescription"].value,
    this.aitForm.controls["aitContactName"].value,
    this.aitForm.controls["aitEmail"].value);
    console.log(this.aitData);

  }
  onCancelClick()
  {
    this.onclose.emit("false");
  };
}
