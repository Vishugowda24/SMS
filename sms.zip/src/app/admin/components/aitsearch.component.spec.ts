import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AitsearchComponent } from './aitsearch.component';

describe('AitsearchComponent', () => {
  let component: AitsearchComponent;
  let fixture: ComponentFixture<AitsearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AitsearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AitsearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
