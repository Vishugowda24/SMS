import { Component, OnInit ,TemplateRef,Input,Output,ElementRef,ViewChild} from '@angular/core';
import {MatTableDataSource,MatTable} from '@angular/material/table';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AdminService } from '../../services/admin.service'
import {MatPaginator} from '@angular/material/paginator';
import { ServiceRequest } from '../../models/ServiceRequest'
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';


interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

// const ELEMENT_DATA: PeriodicElement[] = [
//   {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
//   {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'},
//   {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li'},
//   {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
//   {position: 5, name: 'Boron', weight: 10.811, symbol: 'B'},
//   {position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C'},
//   {position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
//   {position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O'},
//   {position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F'},
//   {position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne'},
// ];
@Component({
  selector: 'app-datapull',
  templateUrl: './datapull.component.html',
  styleUrls: ['./datapull.component.css']
})



export class DatapullComponent implements OnInit {
  displayedColumns: string[] = ['Client','AppID','Url','actions'];
  displayedColumnsData: string[] = ['Client','AppID','Url','actions'];
  ELEMENT_DATA : any;
  public DataPullForm : FormGroup;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;


  dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
  constructor(private  adminService:AdminService,public dialog: MatDialog) { }

  ngOnInit(): void {
    this.createServiceForm();
   this.adminService.getServices().subscribe(data => 
    {
    this.dataSource.data = data;
    this.dataSource.paginator = this.paginator;

   console.log(data)  
  }
   )
  }

  pullData(ur:any)
  {
    let request= new ServiceRequest(ur);
    this.adminService.getServiceData(request).subscribe(data => 
      {
     
  
     console.log(data)  
    }
     )
   
  }
  RowRead(row:any)
  {
    //alert(row)
  }
  createServiceForm()
  {
    this.DataPullForm = 
    new FormGroup({
        aitNumber: new FormControl("",{
          validators : [Validators.required,
            Validators.min(1),
          Validators.maxLength(10000)
         ]
        })});
  }

  

  

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}

