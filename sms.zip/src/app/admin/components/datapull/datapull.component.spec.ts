import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatapullComponent } from './datapull.component';

describe('DatapullComponent', () => {
  let component: DatapullComponent;
  let fixture: ComponentFixture<DatapullComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatapullComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatapullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
